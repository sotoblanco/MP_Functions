from setuptools import setup

setup(
    name="MP_Functions",
    version='0.0.1',
    author="Pastor Soto",
    author_email="sotoblanco263542@gmail.com",
    description='Create market profile pictures',
    py_modules=["MP_Functions"],
    package_dir={'':'libname'},

)